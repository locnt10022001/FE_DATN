import HeaderLayoutAdmin from './HeaderLayoutAdmin';

export default HeaderLayoutAdmin;
