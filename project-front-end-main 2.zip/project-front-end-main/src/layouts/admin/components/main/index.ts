import MainLayoutAdmin from './MainLayoutAdmin';

export default MainLayoutAdmin;
