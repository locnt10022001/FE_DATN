import SidebarLayoutAdmin from './SidebarLayoutAdmin';

export default SidebarLayoutAdmin;
