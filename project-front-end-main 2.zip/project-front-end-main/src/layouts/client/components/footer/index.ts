import FooterLayoutClient from "./FooterLayoutClient";

export default FooterLayoutClient