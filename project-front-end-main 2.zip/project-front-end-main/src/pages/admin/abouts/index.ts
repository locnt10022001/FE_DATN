import ManageAbout from "./ManageAbout";
import ManageAboutUpdate from "./ManageAboutUpdate";

export {ManageAbout,ManageAboutUpdate}