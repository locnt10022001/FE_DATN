import React from 'react'

type Props = {}

const Management = (props: Props) => {
  return (
    <div>Management</div>
  )
}

export default Management