import Management from "./Management";
export default Management