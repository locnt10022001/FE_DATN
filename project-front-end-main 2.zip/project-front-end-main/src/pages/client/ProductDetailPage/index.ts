import ProductDetailPage from "./ProductDetailPage";
export default ProductDetailPage