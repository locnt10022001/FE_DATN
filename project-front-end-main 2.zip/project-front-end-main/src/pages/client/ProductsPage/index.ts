import ProductPage from "./ProductPage";
export default ProductPage