import ProductSale from "./ProductSale";
export default ProductSale