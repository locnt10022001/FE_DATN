import Profiles from "./Profiles";

export default Profiles;
